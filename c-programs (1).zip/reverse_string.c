#include <stdio.h>
#include <string.h>
int main(void) { char text[100]; fgets(text, sizeof(text), stdin); size_t length = strlen(text); if (length && text[length - 1] == '\n') text[--length] = '\0'; for (int i = (int)length - 1; i >= 0; i--) putchar(text[i]); putchar('\n'); return 0; }
