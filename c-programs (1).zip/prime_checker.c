#include <stdio.h>

int main(void) {
    int number, divisor, is_prime = 1;

    printf("Enter a positive integer: ");
    scanf("%d", &number);

    if (number < 2) is_prime = 0;
    for (divisor = 2; divisor * divisor <= number; divisor++) {
        if (number % divisor == 0) { is_prime = 0; break; }
    }

    printf("%d is %s.\n", number, is_prime ? "prime" : "not prime");
    return 0;
}
