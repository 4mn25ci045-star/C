#include <stdio.h>
int main(void) { int n; double value, largest; scanf("%d", &n); scanf("%lf", &largest); for (int i = 1; i < n; i++) { scanf("%lf", &value); if (value > largest) largest = value; } printf("Largest: %.2f\n", largest); return 0; }
