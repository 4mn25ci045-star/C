#include <stdio.h>
#include <string.h>
int main(void) { char text[100]; fgets(text, sizeof(text), stdin); size_t n = strlen(text); if (n && text[n - 1] == '\n') n--; int ok = 1; for (size_t i = 0; i < n / 2; i++) if (text[i] != text[n - 1 - i]) ok = 0; printf("%s\n", ok ? "Palindrome" : "Not a palindrome"); return 0; }
