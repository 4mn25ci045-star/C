#include <stdio.h>
int main(void) { double celsius; scanf("%lf", &celsius); printf("Fahrenheit: %.2f\n", celsius * 9 / 5 + 32); return 0; }
